# 🦁☀️ Shir o Khorshid — Railway Deploy

## 1. Create a Railway project
Create a new project and add a PostgreSQL database.

## 2. Deploy this folder
Upload this repository to GitHub, then in Railway choose:
New Project → Deploy from GitHub Repo.

## 3. Variables
Set these variables on the Web service:

DATABASE_URL = reference the PostgreSQL service's DATABASE_URL
ADMIN_USERNAME = admin
ADMIN_PASSWORD = use-a-strong-password
SECRET_KEY = generate-a-long-random-secret

Railway supplies PORT automatically.

## 4. Start
Railway uses railway.toml / Procfile automatically.

Health check:
GET /health

The app listens on 0.0.0.0:$PORT.
