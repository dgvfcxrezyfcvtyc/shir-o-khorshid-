import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

import jwt
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from sqlalchemy import create_engine, String, Integer, DateTime, Boolean
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./shir.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-me-now")

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer = HTTPBearer(auto_error=False)

class Base(DeclarativeBase): pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

class Server(Base):
    __tablename__ = "servers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    host: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(30), default="unknown")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(engine)

def db():
    s = SessionLocal()
    try: yield s
    finally: s.close()

def seed():
    s = SessionLocal()
    if not s.query(User).filter_by(username=ADMIN_USERNAME).first():
        s.add(User(username=ADMIN_USERNAME, password_hash=pwd.hash(ADMIN_PASSWORD), is_admin=True))
        s.commit()
    s.close()
seed()

app = FastAPI(title="Shir o Khorshid", version="0.1.0")

def current_admin(creds: HTTPAuthorizationCredentials = Depends(bearer), s: Session = Depends(db)):
    if not creds: raise HTTPException(401, "Authentication required")
    try:
        payload = jwt.decode(creds.credentials, SECRET_KEY, algorithms=["HS256"])
    except Exception:
        raise HTTPException(401, "Invalid token")
    user = s.query(User).filter_by(username=payload.get("sub"), is_admin=True).first()
    if not user: raise HTTPException(403, "Admin access required")
    return user

@app.get("/", response_class=HTMLResponse)
def home():
    return HTMLResponse(Path("/app/app/index.html").read_text())

@app.post("/api/login")
async def login(request: Request, s: Session = Depends(db)):
    data = await request.json()
    user = s.query(User).filter_by(username=data.get("username")).first()
    if not user or not pwd.verify(data.get("password",""), user.password_hash):
        raise HTTPException(401, "Invalid username or password")
    token = jwt.encode({"sub": user.username, "exp": datetime.now(timezone.utc)+timedelta(hours=12)}, SECRET_KEY, algorithm="HS256")
    return {"access_token": token}

@app.get("/api/dashboard")
def dashboard(_: User = Depends(current_admin), s: Session = Depends(db)):
    return {"users": s.query(User).count(), "servers": s.query(Server).count(), "version": app.version}

@app.get("/api/users")
def users(_: User = Depends(current_admin), s: Session = Depends(db)):
    return [{"id":u.id,"username":u.username,"is_admin":u.is_admin,"created_at":u.created_at.isoformat()} for u in s.query(User).order_by(User.id.desc()).all()]

@app.post("/api/users")
async def create_user(request: Request, _: User = Depends(current_admin), s: Session = Depends(db)):
    data = await request.json()
    username, password = data.get("username"), data.get("password")
    if not username or not password: raise HTTPException(400, "username and password are required")
    if s.query(User).filter_by(username=username).first(): raise HTTPException(409, "Username already exists")
    u = User(username=username, password_hash=pwd.hash(password), is_admin=bool(data.get("is_admin",False)))
    s.add(u); s.commit(); s.refresh(u)
    return {"id":u.id,"username":u.username}

@app.delete("/api/users/{user_id}")
def delete_user(user_id:int, me:User=Depends(current_admin), s:Session=Depends(db)):
    u=s.get(User,user_id)
    if not u: raise HTTPException(404,"User not found")
    if u.id==me.id: raise HTTPException(400,"You cannot delete yourself")
    s.delete(u); s.commit()
    return {"ok":True}

@app.get("/api/servers")
def servers(_:User=Depends(current_admin), s:Session=Depends(db)):
    return [{"id":x.id,"name":x.name,"host":x.host,"status":x.status} for x in s.query(Server).order_by(Server.id.desc()).all()]

@app.post("/api/servers")
async def create_server(request:Request, _:User=Depends(current_admin), s:Session=Depends(db)):
    d=await request.json()
    if not d.get("name") or not d.get("host"): raise HTTPException(400,"name and host are required")
    x=Server(name=d["name"],host=d["host"],status="unknown")
    s.add(x); s.commit(); s.refresh(x)
    return {"id":x.id,"name":x.name,"host":x.host,"status":x.status}

@app.get("/health")
def health(): return {"status":"ok","service":"shir-o-khorshid"}
