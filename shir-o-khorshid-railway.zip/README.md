# 🦁☀️ Shir o Khorshid

A self-hosted admin dashboard starter built with FastAPI, PostgreSQL, and a lightweight HTML/JS frontend.

## Run
```bash
docker compose up --build -d
```
Open http://localhost:8000

Default demo login:
- username: admin
- password: change-me-now

Change the password before exposing the service publicly.
